#include<stdio.h>
void reverse(int a,int b,int c,int d)
{
	
	b=a/1000;
	a=a%1000;
	
	c=a/100;
	a=a%100;
	
	d=a/10;
	a=a%10;
	
	a++;
	b++;
	c++;
	d++;
	
	printf("The Reverse Order is %d %d %d %d",a,d,c,b);
	
}
int main()
{
	int a,b,c,d;
	printf("Enter a Number:");
	scanf("%d",&a);
	
	reverse(a,b,c,d);
}
