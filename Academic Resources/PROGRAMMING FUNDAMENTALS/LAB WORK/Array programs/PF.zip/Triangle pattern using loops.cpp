#include<stdio.h>
void pattern(int a)
{   
    int z=1;
	for(int i=1; i<=a; i++)
	{
		for(int j=a; j>=0; j--)
		{
			if(j<=i)
			{
				printf("%2d",z);
				z++;
			}
			else
			printf(" ");
		}
		printf("\n");
	}
}
int main()
{  
    int a;
	printf("Enter Range of triangle:");
	scanf("%d",&a);
	pattern(a);
}
