#include<stdio.h>
int main()
{
	int i,num,p=0;
	printf("Enter a number:");
	scanf("%d",&num);
	
	for(i=1; i<=num; i++)
	
	if(num%i==0)
	{
		if(p==2)
		{
			printf("It is Prime number",num);
		}
		else
		{
			printf("It is not a prime number",num);
		}
	}
		
	return 0;
}
