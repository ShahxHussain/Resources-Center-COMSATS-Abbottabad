#include<stdio.h>
int main()
{
	int num1,sum;
	printf("The Multiple of 7 Are:");
	
	for(num1=1; num1<=100; num1++)
	{
	if(num1%7==0)
	{
		printf("\n %d",num1);
		sum+=num1;
	}
    } 
	printf("\nThe Sum of multiples is:%d",sum);
	
	return 0;	
}
