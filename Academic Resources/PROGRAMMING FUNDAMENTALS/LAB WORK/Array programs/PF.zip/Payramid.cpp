#include<stdio.h>
int main()
{
	int i,j,k;
	int r,c;
	printf("Enter Number Of Rows and Coloums:");
	scanf("%d %d",&r,&c);
	
	for(i=1; i<=r; i++)
	{
		for(j=r; j>i; j--)
		{
			printf(" ");
		}
		for(k=1; k<=2*i-1; k++)
		{
			printf("*");
		}
		printf("\n");
	}
}
