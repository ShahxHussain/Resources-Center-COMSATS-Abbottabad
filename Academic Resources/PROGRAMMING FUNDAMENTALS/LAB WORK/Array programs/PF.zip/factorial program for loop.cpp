#include<stdio.h>
int main()
{
	int num,m=1;
	printf("Enter A number :");
	scanf("%d",&num);
	
	for(int i=1; i<=num; i++)
	m=m*i;
	
	printf("The factorail of %d is:%d",num,m);
	
	return 0;
	
}
