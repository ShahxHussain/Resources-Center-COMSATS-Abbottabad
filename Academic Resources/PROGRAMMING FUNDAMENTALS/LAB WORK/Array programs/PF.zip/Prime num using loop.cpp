#include<stdio.h>
int main()
{
	int n,p;
	printf("Enter A Number:");
	scanf("%d",&n);
	
	for(int i=1; i<=n; i++)
	{
		if(n%i==0)
		{
			p++;
		}
	}
	if(p==2)
	{
		printf("It is prime number");
	}
	else
	printf("It is not prime number:");
	
	return 0;
}
