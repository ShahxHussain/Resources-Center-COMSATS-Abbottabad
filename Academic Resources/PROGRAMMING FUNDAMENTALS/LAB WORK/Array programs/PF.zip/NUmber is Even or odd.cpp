#include<stdio.h>
#include<conio.h>
int main()
{
	int num1,num2;
	
	printf("Enter a number\n");
	scanf("%d",&num1);
	
	if(num1%2==0)
	{
		printf("The number is Even");
	}
	
	else
	{
		printf("The number is odd");
	}
	
	getch();
}
