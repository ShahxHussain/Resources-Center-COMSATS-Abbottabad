#include<stdio.h>
int main()
{
	int a,b,c,d;
	printf("Enter a Number");
	scanf("%d",&a);
	
	b=a/1000;
	a=a%1000;
	
	c=a/100;
	a=a%100;
	
	d=a/10;
	a=a%10;
	
	printf("The Reverse Order is %d%d%d%d",a,d,c,b);
	
	return 0;
	
}
