#include<stdio.h>
void reverse(int a)
{
	int b,c,d;

	
	b=a/1000;
	a=a%1000;
	
	c=a/100;
	a=a%100;
	
	d=a/10;
	a=a%10;
	
	
}
int main()
{   
	reverse(1234);
	
}
