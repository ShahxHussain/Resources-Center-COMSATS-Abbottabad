#include<stdio.h>
int main()
{
	int a;
	printf("Enter A Number\n");
	scanf("%d",&a);
	
	printf("The Divior of numbers %d are",a);
	
	for(int i=1; i<=a; i++)
	if((a%i)==0)
	{
		printf("\n%d",i);
	}
	
	return 0;
}


