#include<stdio.h>

int main()
{
	int time ;
	
	printf("Enter the time taken by the worker:");
	scanf("%d",&time);
	
    	if(time>=2 && time<=3)
		{
		printf("Worker is said to be highly efficient");
	    }

		if(time>3 && time<=4)
		{
		printf("Worker is ordered to improve speed");
		}
		
		if(time>4 && time<=5)
		{
		printf("Worker is given training to improve his speed");
	    }
	    
	    
		if(time>5)
		{
		printf("Worker have to leave the company");
        }
        
		return 0;
	
}
