#include<stdio.h>
int main()
{
	int a,b,c,positive,negative,Zero;
	printf("Enter a Numbers:");
	scanf("%d %d %d ",&a,&b,&c);
	
	if(a>0)
	{
		positive++;
	}
	else if(a<0)
	{
		negative++;
	}
	else
	{
		Zero++;
	}
	
	printf("The No Of Positives are %d\n:",positive);
	printf("The No of negatives are %d\n:",negative);
	printf("The No of Zeros Are %d:",Zero);
	
}
