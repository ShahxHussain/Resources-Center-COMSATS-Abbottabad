#include<stdio.h>
#include<conio.h>
int main()
{
	int a,b,c;
	printf("Enter the 3 sides of triangle\n");
	scanf("%d %d %d",&a,&b,&c);
	
	if((a+b>c)||(a+c>b)||(b+a>c))
	{
		printf("The Traingle is valid");
	}
	
	else
	{
		printf("The Traingle is not Valid");
	}
	
	getch();
}
