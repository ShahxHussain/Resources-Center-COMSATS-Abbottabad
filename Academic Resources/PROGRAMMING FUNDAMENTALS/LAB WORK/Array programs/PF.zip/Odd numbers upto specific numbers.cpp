#include<stdio.h>
int num1;
int main()
{
	for(int num1; num1<=20; num1++)
	{
	
	if(num1%2!=0)
	{
		printf("The Odd Numbers are %d\n",num1);
	}
	
    }
	return 0;
}
