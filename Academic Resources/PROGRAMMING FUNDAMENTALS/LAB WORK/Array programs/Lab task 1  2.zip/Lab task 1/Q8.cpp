#include<stdio.h>
#include<string.h>
int main()
{
	char ch[200];
	printf("Enter any string:");
	gets(ch);
	
	if(isdigit==ch)
	{
		printf("It is Digit:");
	}
	if(isalpha==ch)
	{
		printf("It is Alphabet:");
	}
	else
	{
		printf("It is Special Character:");
	}
	
	return 0;
}

