#include<stdio.h>
#include<conio.h>
int main()
{
	int a=10;
	int b=(-10);
	
	printf("The value of a: %d \n",a);
	printf("The value of b: %d",b);
	
	return 0;
}