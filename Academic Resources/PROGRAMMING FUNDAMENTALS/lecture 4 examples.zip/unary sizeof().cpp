#include<stdio.h>
#include<limits.h>
int main()
{
	int a;
	char b;
	float c;
	double d;
	printf("Storage size for int data type:%d \n",sizeof(a));
	printf("Storage size for char data type is: %d \n",sizeof(b));
	printf("Storage size for float data type is %d \n",sizeof(c));
	printf("Storage size for double data type is: %d \n",sizeof(d));
	
	return 0;
	
}