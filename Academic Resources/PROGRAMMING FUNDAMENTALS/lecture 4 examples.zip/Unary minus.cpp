#include<stdio.h>
#include<conio.h>
int main()
{
	int a=5;
	int b=-(a);
	
	int n1=20;
	int n2=-30;
	
	printf("The value of a:%d \n",a);
	printf("The value of b:%d \n",b);
	
	printf("The value of -n1:%d \n",-n1);
	printf("The value of -n2:%d",-n2);
	
	return 0;
}