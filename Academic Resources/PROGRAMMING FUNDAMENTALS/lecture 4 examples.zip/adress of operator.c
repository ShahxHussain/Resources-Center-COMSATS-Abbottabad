#include<stdio.h>
#include<conio.h>
int main()
{
	int a=10;
	int b;
	
	b=&a;
	printf("The value of variable a is: %d",a);
	printf("\n The adress of variable is: %d",b);
	
	return 0;
}