#include<stdio.h>
#include<conio.h>
int main()
{
	int year;
	
	printf("Enter a year");
	scanf("%d",&year);
	
	if(year%400==0)
	{
		printf("The Year is leap");
	}
	
	else if(year%100==0)
	{
		printf("The Year is not leap");
	}
	
	else if(year%4==0)
	{
		printf("The Year is leap");
	}
	
	else
	{
		printf("The Year is not leap");
	}
	
	return 0;
}
