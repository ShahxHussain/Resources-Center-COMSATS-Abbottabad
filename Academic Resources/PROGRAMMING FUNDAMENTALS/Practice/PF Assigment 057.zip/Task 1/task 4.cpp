#include<stdio.h>
#include<conio.h>
int main()
{
	int num1,num2;
	printf("Enter two numbers\n");
	scanf("%d %d",&num1,&num2);
	
	if(num1>num2)
	{
		printf("%d is greator",num1);
	}
	
	else
	printf("%d is greator",num2);
	
	getch();
}
