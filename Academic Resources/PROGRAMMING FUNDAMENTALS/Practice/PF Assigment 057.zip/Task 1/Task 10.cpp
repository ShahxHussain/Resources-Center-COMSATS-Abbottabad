#include<stdio.h>

int main()
{
	int days;
	printf("Enter The day of The Book:");
	scanf("%d",&days);
	
	if(days>=1&&days<=5)
	{
		printf("You Have Fined 50 Paisy\nYou are requested to pay it");
	}
	
	else if(days<=6&&days<=10)
	{
		printf("You Have fined 1 Rupee\nYou are requested to pay it");
	}
	
	else if(days<=10&&days<=30)
	{
		printf("You have fined 5 rupee\nYou are requested to pay it");
	}
	
	else
	{
		printf("Your Memmbership Is cancelled And You can go to home");
	}
	
	return 0;
}
