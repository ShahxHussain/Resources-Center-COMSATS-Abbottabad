#include<stdio.h>
#include<conio.h>
int main()
{
	int num1,num2;
	
	printf("Enter first Number");
	scanf("%d",&num1);
	
	printf("Enter 2nd number");
	scanf("%d",&num2);
	
	if(num1%num2==0)
	{
		printf("The first Number is factor of second");
	}
	
	else
	{
		printf("The first Number is not factor of second");
	}
	
	getch();
}
