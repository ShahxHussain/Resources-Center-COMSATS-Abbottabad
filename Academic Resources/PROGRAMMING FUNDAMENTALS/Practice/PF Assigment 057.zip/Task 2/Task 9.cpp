#include<stdio.h>
#include<math.h>
int main()
{
	int num1,num2,result;
	printf("Enter 2 nnumbers\n");
	scanf("%d %d",&num1,&num2);
	
	result=pow(num1,num2);
	printf("The number %d is raised to the power of %d is %d=%d",num1,num2,result);
	
	return 0;
	
}
