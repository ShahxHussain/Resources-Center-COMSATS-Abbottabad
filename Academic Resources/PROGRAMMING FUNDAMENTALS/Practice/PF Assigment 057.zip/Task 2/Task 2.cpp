#include<stdio.h>
int num1;
int main()
{
	for(int num1=1; num1<=10; num1++)
	if(num1<=10)
	{
		printf("%d\n",num1);
	}
	
	return 0;
}
