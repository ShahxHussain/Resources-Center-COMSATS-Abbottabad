#include<stdio.h>
int num1;
int main()
{
	for(int num1=50; num1<=70; num1++)
	if(num1%2==0)
	{
		printf("The Even Numbers are %d\n",num1);
	}
	
	return 0;
}
