#include<stdio.h>
int main()
{
	int a;
	
	printf("Enter a number\n");
	scanf("%d",&a);
	
	printf("The Factors of Number %d is:",a);
	
	for(int i=1; i<=20; i++)
	if(i%a==0)
	{
		printf("\n%d",i);
	}
	
	return 0;
}
