#include<stdio.h>
int main()
{
	for(int i; i<=20; i++)
	printf("My Name is Mahad\n");
	
	return 0;
}
